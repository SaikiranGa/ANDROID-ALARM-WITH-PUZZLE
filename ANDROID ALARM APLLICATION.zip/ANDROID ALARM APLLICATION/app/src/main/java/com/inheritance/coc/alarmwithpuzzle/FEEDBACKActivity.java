package com.inheritance.coc.alarmwithpuzzle;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class FEEDBACKActivity extends AppCompatActivity {


    TextView feedback;
    RatingBar ratingBar;
    Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedbackactivity);

        feedback= findViewById(R.id.feedback);
        button2=findViewById(R.id.button2);
        ratingBar=findViewById(R.id.ratingBar);


        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if(rating==0){
                    feedback.setText("Avoid");
                }
                else if(rating==1){
                    feedback.setText("ok");
                }
                else if(rating==2){
                    feedback.setText("good");
                }
                else if(rating==3){
                    feedback.setText("very good");
                }
                else if(rating==4){
                    feedback.setText("outstanding");
                }
                else {
                    feedback.setText("osm");
                }

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("saikirangarshakurthi@gmail.com");
            }
        });
    }

    private void gotoUrl(String s) {
        Uri uri=Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW));
    }
}